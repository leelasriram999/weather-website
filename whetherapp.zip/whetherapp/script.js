const apiKey = 'e40da34262bb767d07abb8d3527778e0'; // Keep the key for weather API here
const apiUrl = 'https://api.openweathermap.org/data/2.5/weather';
const forecastUrl = 'https://api.openweathermap.org/data/2.5/forecast';  // 5-day forecast API
const backendUrl = 'http://localhost:5000/forecast';  // Backend URL for storing/retrieving forecast

const locationInput = document.getElementById('locationInput');
const searchButton = document.getElementById('searchButton');
const locationElement = document.getElementById('location');
const temperatureElement = document.getElementById('temperature');
const descriptionElement = document.getElementById('description');
const forecastElement = document.getElementById('forecast');

searchButton.addEventListener('click', () => {
    const location = locationInput.value;
    if (location) {
        fetchWeather(location);
        fetchForecast(location);
    }
});

function fetchWeather(location) {
    const url = `${apiUrl}?q=${location}&appid=${apiKey}&units=metric`;

    fetch(url)
        .then(response => response.json())
        .then(data => {
            locationElement.textContent = data.name;
            temperatureElement.textContent = `${Math.round(data.main.temp)}°C`;
            descriptionElement.textContent = data.weather[0].description;

            // Set background image based on weather description
            const weather = data.weather[0].main;
            setBackground(weather);
        })
        .catch(error => {
            console.error('Error fetching weather data:', error);
        });
}

function fetchForecast(location) {
    const url = `${forecastUrl}?q=${location}&appid=${apiKey}&units=metric`;

    fetch(url)
        .then(response => response.json())
        .then(data => {
            const forecastData = data.list.slice(0, 5);  // Get first 5 forecast entries
            forecastElement.innerHTML = '';  // Clear previous forecast

            forecastData.forEach(day => {
                const forecastDay = document.createElement('div');
                forecastDay.classList.add('forecast-day');
                
                const date = new Date(day.dt * 1000);  // Convert from UNIX timestamp
                const dayName = date.toLocaleDateString('en-GB', { weekday: 'short' });
                const temperature = Math.round(day.main.temp);
                const description = day.weather[0].description;
                const icon = `https://openweathermap.org/img/wn/${day.weather[0].icon}.png`;

                forecastDay.innerHTML = `
                    <h4>${dayName}</h4>
                    <img src="${icon}" alt="${description}">
                    <p>${temperature}°C</p>
                    <p>${description}</p>
                `;

                forecastElement.appendChild(forecastDay);
            });

            // Store forecast in backend
            storeForecastInBackend(location, forecastData);
        })
        .catch(error => {
            console.error('Error fetching forecast data:', error);
        });
}

function storeForecastInBackend(location, forecastData) {
    fetch(backendUrl, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ location, forecast: forecastData }),
    })
    .then(response => response.json())
    .then(data => {
        console.log('Forecast stored successfully:', data);
    })
    .catch(error => {
        console.error('Error storing forecast data:', error);
    });
}

function setBackground(weather) {
    let backgroundImageUrl;

    switch (weather) {
        case 'Clear':
            backgroundImageUrl = 'url("clear.jpg")';
            break;
        case 'Clouds':
            backgroundImageUrl = 'url("cloudy.jpg")';
            break;
        case 'Rain':
            backgroundImageUrl = 'url("rainy.jpg")';
            break;
        case 'Mist':
        case 'Fog':
        case 'Haze':
            backgroundImageUrl = 'url("misty.jpg")';
            break;
        case 'Thunderstorm':
            backgroundImageUrl = 'url("stormy.jpg")';
            break;
        default:
            backgroundImageUrl = 'url("default.jpg")';
            break;
    }

    document.body.style.backgroundImage = backgroundImageUrl;
    document.body.style.backgroundSize = 'cover';
    document.body.style.backgroundPosition = 'center';
    document.body.style.backgroundRepeat = 'no-repeat';
}
