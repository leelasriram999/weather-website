const express = require('express');
const mongoose = require('mongoose');
const axios = require('axios');

// Initialize the app
const app = express();
const port = 5000;

// Middleware
app.use(express.json());

// Connect to MongoDB
mongoose.connect('mongodb://localhost/weather-app', {
    useNewUrlParser: true,
    useUnifiedTopology: true,
})
    .then(() => console.log('Connected to MongoDB'))
    .catch((error) => console.log(error));

// Forecast Schema
const forecastSchema = new mongoose.Schema({
    location: String,
    forecast: Array,
    date: { type: Date, default: Date.now },
});

const Forecast = mongoose.model('Forecast', forecastSchema);

// Fetch 5-day forecast from OpenWeather API
const apiKey = 'YOUR_OPENWEATHER_API_KEY';
const forecastUrl = 'https://api.openweathermap.org/data/2.5/forecast';

// Route to save 5-day forecast in MongoDB
app.post('/forecast', async (req, res) => {
    const { location } = req.body;

    try {
        const response = await axios.get(`${forecastUrl}?q=${location}&appid=${apiKey}&units=metric`);
        const forecastData = response.data.list.slice(0, 5); // Get first 5 forecast items

        // Save forecast to database
        const forecast = new Forecast({
            location,
            forecast: forecastData,
        });

        await forecast.save();
        res.status(201).json(forecast);
    } catch (error) {
        res.status(500).json({ message: 'Error fetching or saving forecast', error });
    }
});

// Route to retrieve stored forecasts
app.get('/forecast/:location', async (req, res) => {
    const { location } = req.params;

    try {
        const forecast = await Forecast.findOne({ location }).sort({ date: -1 });
        if (!forecast) {
            return res.status(404).json({ message: 'Forecast not found' });
        }
        res.json(forecast);
    } catch (error) {
        res.status(500).json({ message: 'Error retrieving forecast', error });
    }
});

// Start the server
app.listen(port, () => {
    console.log(`Server running on http://localhost:${port}`);
});
